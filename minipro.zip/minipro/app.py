import streamlit as st
import os
import datetime
import pandas as pd
from dotenv import load_dotenv
from models import StudyInput
from llm_service import extract_study_input, generate_explanation
from fuzzy_engine import evaluate_readiness, get_readiness_label, plot_membership_functions

load_dotenv()

st.set_page_config(page_title="Smart Study Readiness Advisor", layout="centered")

# Import FontAwesome for professional icons
st.markdown('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">', unsafe_allow_html=True)

st.markdown("""
<style>
    /* Professional subtle dot background */
    .stApp {
        background-color: transparent;
        background-image: radial-gradient(rgba(128, 128, 128, 0.15) 1px, transparent 1px);
        background-size: 20px 20px;
    }
    /* Modern button styling */
    div.stButton > button:first-child {
        background-color: #4CAF50;
        color: white;
        border-radius: 8px;
        border: none;
        padding: 10px 24px;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    div.stButton > button:first-child:hover {
        background-color: #45a049;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    /* Footer */
    .developer-footer {
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        background-color: transparent;
        text-align: center;
        padding: 12px;
        font-size: 15px;
        font-weight: 500;
        z-index: 100;
        opacity: 0.8;
    }
    /* Metrics customization */
    [data-testid="stMetricValue"] {
        font-size: 2.5rem !important;
    }
    /* Hide Streamlit default header */
    header[data-testid="stHeader"] {
        display: none !important;
    }
    
    /* Ensure content doesn't get hidden behind the fixed navbar */
    .block-container {
        padding-top: 90px !important;
    }

    /* Professional Top Navbar styling */
    .top-navbar {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        background-color: #1E293B;
        color: #F8FAFC;
        padding: 15px 40px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        z-index: 9999;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .top-navbar .brand {
        font-size: 1.4rem;
        font-weight: 700;
        letter-spacing: 0.5px;
    }
</style>
""", unsafe_allow_html=True)

# Render the Navbar
st.markdown("""
<div class="top-navbar">
    <div class="brand"><i class="fa-solid fa-graduation-cap"></i> SmartAdvisor</div>
</div>
""", unsafe_allow_html=True)

st.markdown("<h1 style='text-align: center;'><i class='fa-solid fa-chart-line' style='color: #4CAF50;'></i> Smart Study Readiness Advisor</h1>", unsafe_allow_html=True)
st.markdown("<h4 style='text-align: center; color: gray; font-weight: 400;'>Understand your preparation level using LLM + Fuzzy Logic</h4>", unsafe_allow_html=True)
st.divider()

# Ensure API Key is present
if not os.getenv("GROQ_API_KEY"):
    st.error("Missing GROQ_API_KEY in environment variables. Please check your .env file or Streamlit secrets.")
    st.stop()

# --- Initialize session state ---
if 'extracted_inputs' not in st.session_state:
    st.session_state.extracted_inputs = None
if 'fuzzy_score' not in st.session_state:
    st.session_state.fuzzy_score = None
if 'readiness_label' not in st.session_state:
    st.session_state.readiness_label = None
if 'explanation' not in st.session_state:
    st.session_state.explanation = None

if 'history' not in st.session_state:
    st.session_state.history = []

# --- Navigation Setup ---
st.sidebar.markdown("## <i class='fa-solid fa-compass'></i> Navigation", unsafe_allow_html=True)
page = st.sidebar.radio("", ["Dashboard", "About the Project", "Developer Info", "Privacy Policy"])

if page == "About the Project":
    st.markdown("### <i class='fa-solid fa-book-open'></i> About the Project", unsafe_allow_html=True)
    st.write(
        "The **Smart Study Readiness Advisor** is an innovative academic tool designed to help students "
        "objectively evaluate their exam preparation. By combining the natural language understanding "
        "capabilities of Large Language Models (LLMs) with the mathematical reasoning of **Fuzzy Logic**, "
        "it translates vague feelings of readiness into a concrete, actionable score."
    )
    st.write("#### How it works:")
    st.write("1. **Extraction:** An LLM reads your study situation and extracts exact metrics.")
    st.write("2. **Inference:** A 13-rule fuzzy logic engine processes these metrics to determine readiness without rigid thresholds.")
    st.write("3. **Explanation:** The LLM provides contextual advice based on the fuzzy calculation.")
    st.stop()

elif page == "Developer Info":
    st.markdown("### <i class='fa-solid fa-code'></i> Developer Info", unsafe_allow_html=True)
    st.write("This project was developed by **Sweta Pal**.")
    st.write("It serves as a demonstration of integrating Generative AI with traditional AI expert systems (Fuzzy Logic) in a clean, professional web application.")
    st.stop()

elif page == "Privacy Policy":
    st.markdown("### <i class='fa-solid fa-shield-halved'></i> Privacy Policy", unsafe_allow_html=True)
    st.write("Your privacy is extremely important to us.")
    st.write("- **Data Collection:** We do not collect, store, or sell any of the personal study information you enter.")
    st.write("- **API Usage:** Your text input is sent securely to the Groq API solely for the purpose of metric extraction.")
    st.write("- **Local State:** History tracking happens exclusively within your browser's session state and is erased as soon as you refresh or close the tab.")
    st.stop()

# --- Section 1: Describe Your Study Situation ---
st.markdown("### <i class='fa-solid fa-pen-to-square'></i> 1. Describe Your Study Situation", unsafe_allow_html=True)

default_text = (
    "I have my final Data Structures and Algorithms exam in exactly 4 days. "
    "I've managed to complete roughly 75% of the total syllabus so far. "
    "I'm dedicating about 6 hours per day to studying right now. "
    "However, I've been quite stressed and only got 5 hours of sleep last night. "
    "Overall, my confidence level for passing the exam is around a 6 out of 10."
)

user_text = st.text_area(
    "Provide a detailed description of your current preparation...",
    value=default_text,
    height=150
)

if st.button("Analyze My Readiness", type="primary"):
    if not user_text.strip():
        st.warning("Please describe your study situation first.")
    else:
        with st.spinner("Extracting parameters with LangChain + Groq..."):
            try:
                # LLM Extraction
                extracted = extract_study_input(user_text)
                st.session_state.extracted_inputs = extracted
                # Clear previous results to force recalculation based on new or edited values
                st.session_state.fuzzy_score = None
                st.session_state.readiness_label = None
                st.session_state.explanation = None
            except Exception as e:
                st.error(f"Error during LLM extraction: {e}")

# --- Section 2: Extracted Inputs ---
if st.session_state.extracted_inputs is not None:
    st.markdown("### <i class='fa-solid fa-sliders'></i> 2. Extracted Inputs", unsafe_allow_html=True)
    st.write("The LLM extracted these values. You can correct them if needed.")
    
    col1, col2 = st.columns(2)
    with col1:
        days = st.number_input("Days to Exam (0-30)", min_value=0.0, max_value=30.0, value=float(st.session_state.extracted_inputs.days_to_exam))
        syllabus = st.number_input("Syllabus Completion % (0-100)", min_value=0.0, max_value=100.0, value=float(st.session_state.extracted_inputs.syllabus_completion))
        study_hours = st.number_input("Study Hours / Day (0-12)", min_value=0.0, max_value=12.0, value=float(st.session_state.extracted_inputs.study_hours_per_day))
    with col2:
        sleep = st.number_input("Sleep Hours (0-12)", min_value=0.0, max_value=12.0, value=float(st.session_state.extracted_inputs.sleep_hours))
        confidence = st.number_input("Confidence / 10", min_value=0.0, max_value=10.0, value=float(st.session_state.extracted_inputs.confidence))
    
    if st.button("Recalculate"):
        # Update session state with potentially modified inputs
        updated_input = StudyInput(
            days_to_exam=days,
            syllabus_completion=syllabus,
            study_hours_per_day=study_hours,
            sleep_hours=sleep,
            confidence=confidence
        )
        st.session_state.extracted_inputs = updated_input
        
        with st.spinner("Calculating fuzzy logic and generating explanation..."):
            try:
                # Fuzzy Inference
                score = evaluate_readiness(updated_input)
                label = get_readiness_label(score)
                
                st.session_state.fuzzy_score = score
                st.session_state.readiness_label = label
                
                # LLM Explanation
                explanation = generate_explanation(updated_input, score, label)
                st.session_state.explanation = explanation
                # Update History
                st.session_state.history.append({
                    "timestamp": datetime.datetime.now().strftime("%H:%M:%S"),
                    "score": score,
                    "label": label
                })
            except Exception as e:
                st.error(f"Error processing readiness: {e}")

# --- Section 3 & 4: Fuzzy Analysis & Why? ---
if st.session_state.fuzzy_score is not None:
    st.divider()
    st.markdown("### <i class='fa-solid fa-chart-pie'></i> 3. Fuzzy Analysis", unsafe_allow_html=True)
    
    score = st.session_state.fuzzy_score
    label = st.session_state.readiness_label
    
    col1, col2 = st.columns(2)
    with col1:
        st.metric(label="Readiness Score", value=f"{score:.1f} / 100")
    with col2:
        st.metric(label="Category", value=f"{label.upper()} READINESS")
        
    st.progress(score / 100.0)
    
    st.markdown("### <i class='fa-solid fa-lightbulb'></i> 4. Why?", unsafe_allow_html=True)
    st.info(st.session_state.explanation)
    
    # Download Report Feature
    report_content = f"# Smart Study Readiness Report\n\n**Score:** {score:.1f} / 100\n**Category:** {label.upper()}\n\n## Analysis\n{st.session_state.explanation}\n\n*Generated by SmartAdvisor*"
    st.download_button("Download Report 📄", data=report_content, file_name="readiness_report.md", mime="text/markdown", type="secondary")

    # History Trend Feature
    if len(st.session_state.history) > 1:
        st.divider()
        st.markdown("### <i class='fa-solid fa-clock-rotate-left'></i> Readiness Trend", unsafe_allow_html=True)
        st.write("Track how your readiness score changes as you adjust your study parameters.")
        history_df = pd.DataFrame(st.session_state.history)
        st.line_chart(history_df.set_index("timestamp")["score"])

    # --- Section 5: Membership Visualization ---
    st.divider()
    st.markdown("### <i class='fa-solid fa-wave-square'></i> 5. Membership Visualization", unsafe_allow_html=True)
    st.write("These charts show the underlying fuzzy sets and membership functions used in the inference engine.")
    
    with st.expander("Show Fuzzy Memberships"):
        figs = plot_membership_functions()
        col_a, col_b = st.columns(2)
        with col_a:
            st.pyplot(figs['syllabus'].figure)
            st.pyplot(figs['confidence'].figure)
        with col_b:
            st.pyplot(figs['study_hours'].figure)
            st.pyplot(figs['readiness'].figure)

# --- Footer ---
st.markdown('<div class="developer-footer"><i class="fa-solid fa-code"></i> Developed by <b>Sweta Pal</b></div>', unsafe_allow_html=True)
