# Smart Study Readiness Advisor

## Project Overview
The **Smart Study Readiness Advisor** is a complete, locally runnable web application that helps students assess their exam readiness. It takes natural language input about a student's study situation, parses it using a Large Language Model (LLM), evaluates the preparation using a genuine Fuzzy Logic inference system, and provides an explainable Readiness Score.

## Problem Statement
Students often know their preparation qualitatively (e.g., "I feel okay but I haven't slept much") but struggle to assess readiness objectively. This app bridges the gap between qualitative feelings and quantitative assessment.

## Features
* **Natural language input**: Describe your study situation exactly as you would to a friend.
* **LLM-based information extraction**: LangChain + Groq parses unstructured text into structured numerical data.
* **Fuzzy inference**: A 12+ rule fuzzy logic system evaluates non-binary, overlapping linguistic categories.
* **Readiness score**: Defuzzified 0-100 score indicating exam preparedness.
* **Explainable result**: The LLM translates the fuzzy logic output back into human-friendly advice.
* **Membership function visualization**: View the mathematical membership functions used in inference.
* **Streamlit UI**: Clean, interactive single-page web interface.

## Technologies
* Python 3.11+
* Streamlit
* LangChain & LangChain-Groq
* Groq LLM (via API)
* scikit-fuzzy
* Pydantic
* Matplotlib

## Architecture
```text
User → LangChain LLM → Structured Data → Fuzzy Engine → Score → LangChain Explanation
```

### How the AI component works
The LangChain LLM (Groq) understands free-form text and extracts structured study parameters using Pydantic schemas. It converts expressions like "roughly seventy percent" into integers like `70` without needing rigid regular expressions. Later, the LLM takes the fuzzy logic results and generates conversational advice.

### How fuzzy logic works
The extracted numerical values are fuzzified into linguistic categories such as Low, Medium, and High using `scikit-fuzzy`. A predefined set of fuzzy rules evaluates these categories, and centroid defuzzification produces a final readiness score (0-100).

### Why both are needed
The LLM handles natural-language understanding, interpreting messy human input. The fuzzy logic system handles the actual mathematical reasoning, ensuring a robust, deterministic calculation based on gradual decision boundaries (uncertainty), which is much better than brittle `if/else` statements.

## Run Locally

**1. Create a virtual environment:**
```bash
python -m venv .venv
```

**2. Activate the virtual environment:**
*Windows:*
```bash
.venv\Scripts\activate
```
*Mac/Linux:*
```bash
source .venv/bin/activate
```

**3. Install dependencies:**
```bash
pip install -r requirements.txt
```

**4. Set up environment variables:**
Rename `.env.example` to `.env` and add your Groq API key:
```env
GROQ_API_KEY=your_actual_key_here
```

**5. Run the Streamlit app:**
```bash
streamlit run app.py
```

## Environment Setup
Create a file named `.env` in the root directory.
It should contain:
```env
GROQ_API_KEY=...
```
You can get a free API key from [Groq Console](https://console.groq.com/).

## Deployment
To deploy on Streamlit Community Cloud:
1. Push this repository to GitHub.
2. Go to [share.streamlit.io](https://share.streamlit.io/).
3. Click "New app" and point it to your repository and `app.py`.
4. In the Streamlit dashboard, go to **Advanced settings > Secrets** and add:
   ```toml
   GROQ_API_KEY = "your_actual_key_here"

   ```
5. Click "Deploy".

## Test Cases

### Test 1
**Input:**
```text
My exam is tomorrow. I have completed only 30% of the syllabus, study 2 hours per day, slept 4 hours and my confidence is 2/10.
```
**Expected general result:**
Low / Poor readiness.

### Test 2
**Input:**
```text
My exam is in 10 days. I have finished 80% of the syllabus, study 5 hours daily, slept 7 hours and confidence is 8/10.
```
**Expected general result:**
High / Excellent readiness.

### Test 3
**Input:**
```text
I have 3 days left. Syllabus completion is around 60%. I study 6 hours, sleep 8, confidence is 5.
```
**Expected general result:**
Moderate to Good readiness.

### Test 4
**Input:**
```text
Exam is far away in 20 days. Finished 95% of syllabus. Confidence is 9. Sleeping 8 hours and studying 3 hours.
```
**Expected general result:**
Excellent readiness.

### Test 5
**Input:**
```text
Exam tomorrow. Done 100% syllabus but haven't slept at all (0 hours). Confidence 4. Study 10 hours.
```
**Expected general result:**
Moderate readiness (high syllabus but penalized by poor sleep and low confidence).
