from pydantic import BaseModel, Field

class StudyInput(BaseModel):
    days_to_exam: float = Field(description="Days remaining until the exam. Range: 0 to 30.")
    syllabus_completion: float = Field(description="Percentage of syllabus completed. Range: 0 to 100.")
    study_hours_per_day: float = Field(description="Number of hours the student studies per day. Range: 0 to 12.")
    sleep_hours: float = Field(description="Hours of sleep the student gets. Range: 0 to 12.")
    confidence: float = Field(description="Student's confidence level out of 10. Range: 0 to 10.")
