import os
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate
from models import StudyInput
from dotenv import load_dotenv

load_dotenv()

def get_llm():
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        raise ValueError("GROQ_API_KEY environment variable not set. Please check your .env file.")
    # Using a fast, reliable model for extraction and explanation
    # Capping max_tokens to 300 to stay safely under Groq's 1000 OTPM free tier limit
    return ChatGroq(temperature=0, model_name="qwen/qwen3.8-27b", groq_api_key=api_key, max_tokens=300)

def extract_study_input(text: str) -> StudyInput:
    llm = get_llm()
    structured_llm = llm.with_structured_output(StudyInput)
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are an expert academic assistant. Your task is to extract study preparation parameters from the user's natural language input.\n\n"
                   "Infer obvious expressions (e.g., 'roughly 70%' -> 70, 'five days' -> 5, '7/10 confidence' -> 7).\n"
                   "Return the structured values. Never invent missing information; use reasonable defaults only if genuinely omitted. Range requirements:\n"
                   "- days_to_exam: 0-30\n"
                   "- syllabus_completion: 0-100\n"
                   "- study_hours_per_day: 0-12\n"
                   "- sleep_hours: 0-12\n"
                   "- confidence: 0-10"),
        ("human", "{text}")
    ])
    
    chain = prompt | structured_llm
    return chain.invoke({"text": text})

def generate_explanation(study_input: StudyInput, score: float, category: str) -> str:
    llm = get_llm()
    
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are an encouraging academic advisor. The user has been evaluated by a Fuzzy Logic system which calculated their readiness score.\n"
                   "You must provide a concise, conversational explanation based on their inputs, score, and category.\n"
                   "DO NOT calculate any scores yourself. Just explain the results provided to you.\n"
                   "Highlight major contributing factors (e.g., low sleep, high syllabus completion). Keep it under 4-5 sentences."),
        ("human", "My inputs: Days to exam: {days}, Syllabus completion: {syllabus}%, Study hours: {study}, Sleep hours: {sleep}, Confidence: {confidence}/10.\n"
                  "My Readiness Score: {score}/100. Category: {category}.\n\n"
                  "Please explain why I got this result and give brief advice.")
    ])
    
    chain = prompt | llm
    result = chain.invoke({
        "days": study_input.days_to_exam,
        "syllabus": study_input.syllabus_completion,
        "study": study_input.study_hours_per_day,
        "sleep": study_input.sleep_hours,
        "confidence": study_input.confidence,
        "score": round(score, 1),
        "category": category
    })
    
    return result.content
