import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl
from models import StudyInput
import matplotlib.pyplot as plt

def create_fuzzy_system():
    # 1. Inputs and Outputs
    days = ctrl.Antecedent(np.arange(0, 31, 1), 'days_to_exam')
    syllabus = ctrl.Antecedent(np.arange(0, 101, 1), 'syllabus_completion')
    study_hours = ctrl.Antecedent(np.arange(0, 13, 1), 'study_hours')
    sleep = ctrl.Antecedent(np.arange(0, 13, 1), 'sleep')
    confidence = ctrl.Antecedent(np.arange(0, 11, 1), 'confidence')
    
    readiness = ctrl.Consequent(np.arange(0, 101, 1), 'readiness', defuzzify_method='centroid')

    # 2. Membership Functions
    # Days to Exam
    days['very_near'] = fuzz.trapmf(days.universe, [0, 0, 2, 5])
    days['near'] = fuzz.trimf(days.universe, [3, 7, 14])
    days['moderate'] = fuzz.trimf(days.universe, [10, 15, 22])
    days['far'] = fuzz.trapmf(days.universe, [18, 25, 30, 30])
    
    # Syllabus Completion
    syllabus['low'] = fuzz.trapmf(syllabus.universe, [0, 0, 30, 50])
    syllabus['medium'] = fuzz.trimf(syllabus.universe, [35, 60, 80])
    syllabus['high'] = fuzz.trapmf(syllabus.universe, [65, 85, 100, 100])
    
    # Study Hours
    study_hours['low'] = fuzz.trapmf(study_hours.universe, [0, 0, 2, 4])
    study_hours['medium'] = fuzz.trimf(study_hours.universe, [3, 5, 8])
    study_hours['high'] = fuzz.trapmf(study_hours.universe, [6, 9, 12, 12])
    
    # Sleep
    sleep['poor'] = fuzz.trapmf(sleep.universe, [0, 0, 4, 6])
    sleep['adequate'] = fuzz.trimf(sleep.universe, [5, 7, 9])
    sleep['good'] = fuzz.trapmf(sleep.universe, [7, 9, 12, 12])
    
    # Confidence
    confidence['low'] = fuzz.trapmf(confidence.universe, [0, 0, 3, 5])
    confidence['medium'] = fuzz.trimf(confidence.universe, [4, 6, 8])
    confidence['high'] = fuzz.trapmf(confidence.universe, [7, 9, 10, 10])
    
    # Readiness Output
    readiness['poor'] = fuzz.trapmf(readiness.universe, [0, 0, 25, 45])
    readiness['moderate'] = fuzz.trimf(readiness.universe, [35, 55, 75])
    readiness['good'] = fuzz.trimf(readiness.universe, [60, 75, 90])
    readiness['excellent'] = fuzz.trapmf(readiness.universe, [80, 90, 100, 100])
    
    # 3. Rules (At least 12 meaningful rules)
    rule1 = ctrl.Rule(syllabus['low'] & days['very_near'], readiness['poor'])
    rule2 = ctrl.Rule(syllabus['high'] & confidence['high'] & study_hours['high'], readiness['excellent'])
    rule3 = ctrl.Rule(syllabus['medium'] & days['moderate'] & confidence['medium'], readiness['good'])
    rule4 = ctrl.Rule(sleep['poor'] & confidence['low'], readiness['poor'])
    rule5 = ctrl.Rule(syllabus['high'] & study_hours['medium'] & confidence['medium'], readiness['good'])
    rule6 = ctrl.Rule(syllabus['medium'] & sleep['adequate'] & days['near'], readiness['moderate'])
    rule7 = ctrl.Rule(syllabus['low'] & days['far'] & study_hours['high'], readiness['moderate'])
    rule8 = ctrl.Rule(syllabus['high'] & days['very_near'] & sleep['poor'], readiness['moderate'])
    rule9 = ctrl.Rule(confidence['high'] & sleep['good'] & days['far'], readiness['excellent'])
    rule10 = ctrl.Rule(syllabus['medium'] & study_hours['low'] & days['near'], readiness['poor'])
    rule11 = ctrl.Rule(syllabus['low'] & sleep['good'] & study_hours['medium'], readiness['moderate'])
    rule12 = ctrl.Rule(syllabus['high'] & confidence['medium'] & days['moderate'], readiness['good'])
    rule13 = ctrl.Rule(syllabus['high'] & confidence['high'] & days['far'], readiness['excellent'])

    rules = [rule1, rule2, rule3, rule4, rule5, rule6, rule7, rule8, rule9, rule10, rule11, rule12, rule13]
    
    # 4. Control System
    readiness_ctrl = ctrl.ControlSystem(rules)
    return ctrl.ControlSystemSimulation(readiness_ctrl), (days, syllabus, study_hours, sleep, confidence, readiness)

def evaluate_readiness(inputs: StudyInput) -> float:
    sim, _ = create_fuzzy_system()
    
    sim.input['days_to_exam'] = min(max(inputs.days_to_exam, 0), 30)
    sim.input['syllabus_completion'] = min(max(inputs.syllabus_completion, 0), 100)
    sim.input['study_hours'] = min(max(inputs.study_hours_per_day, 0), 12)
    sim.input['sleep'] = min(max(inputs.sleep_hours, 0), 12)
    sim.input['confidence'] = min(max(inputs.confidence, 0), 10)
    
    sim.compute()
    return sim.output['readiness']

def get_readiness_label(score: float) -> str:
    if score <= 30:
        return "Poor"
    elif score <= 55:
        return "Moderate"
    elif score <= 80:
        return "Good"
    else:
        return "Excellent"

def plot_membership_functions():
    _, vars_tuple = create_fuzzy_system()
    days, syllabus, study_hours, sleep, confidence, readiness = vars_tuple
    
    figs = {}
    
    # Syllabus
    fig1, ax1 = plt.subplots(figsize=(6, 3))
    for label in syllabus.terms:
        ax1.plot(syllabus.universe, syllabus[label].mf, label=label)
    ax1.set_title('Syllabus Completion (%)')
    ax1.legend()
    figs['syllabus'] = fig1
    
    # Study Hours
    fig2, ax2 = plt.subplots(figsize=(6, 3))
    for label in study_hours.terms:
        ax2.plot(study_hours.universe, study_hours[label].mf, label=label)
    ax2.set_title('Study Hours (per day)')
    ax2.legend()
    figs['study_hours'] = fig2
    
    # Confidence
    fig3, ax3 = plt.subplots(figsize=(6, 3))
    for label in confidence.terms:
        ax3.plot(confidence.universe, confidence[label].mf, label=label)
    ax3.set_title('Confidence (0-10)')
    ax3.legend()
    figs['confidence'] = fig3
    
    # Readiness
    fig4, ax4 = plt.subplots(figsize=(6, 3))
    for label in readiness.terms:
        ax4.plot(readiness.universe, readiness[label].mf, label=label)
    ax4.set_title('Readiness Score (0-100)')
    ax4.legend()
    figs['readiness'] = fig4
    
    return figs
